#ifndef included_crypto_api_enum_h
#define included_crypto_api_enum_h
typedef enum {
   VL_API_CRYPTO_SET_ASYNC_DISPATCH,
   VL_API_CRYPTO_SET_ASYNC_DISPATCH_REPLY,
   VL_API_CRYPTO_SET_ASYNC_DISPATCH_V2,
   VL_API_CRYPTO_SET_ASYNC_DISPATCH_V2_REPLY,
   VL_API_CRYPTO_SET_HANDLER,
   VL_API_CRYPTO_SET_HANDLER_REPLY,
   VL_MSG_CRYPTO_LAST
} vl_api_crypto_enum_t;
#endif
