/* SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2023 Cisco Systems, Inc.
 */

#ifndef _VNET_DEV_MGMT_H_
#define _VNET_DEV_MGMT_H_

#include <vppinfra/clib.h>

#endif /* _VNET_DEV_MGMT_H_ */
