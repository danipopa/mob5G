#ifndef included_pipe_api_enum_h
#define included_pipe_api_enum_h
typedef enum {
   VL_API_PIPE_CREATE,
   VL_API_PIPE_CREATE_REPLY,
   VL_API_PIPE_DELETE,
   VL_API_PIPE_DELETE_REPLY,
   VL_API_PIPE_DUMP,
   VL_API_PIPE_DETAILS,
   VL_MSG_PIPE_LAST
} vl_api_pipe_enum_t;
#endif
