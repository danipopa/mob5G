/* Imported API files */
#ifndef included_ethernet_types_api_fromjson_h
#define included_ethernet_types_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vppinfra/jsonformat.h>

#pragma GCC diagnostic ignored "-Wunused-label"
/* Manual print mac_address */
#endif
