#ifndef __included_hpp_http_static_api_json
#define __included_hpp_http_static_api_json

#include <vapi/vapi.hpp>
#include <vapi/http_static.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_http_static_enable_v2>(vapi_msg_http_static_enable_v2 *msg)
{
  vapi_msg_http_static_enable_v2_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_http_static_enable_v2>(vapi_msg_http_static_enable_v2 *msg)
{
  vapi_msg_http_static_enable_v2_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_http_static_enable_v2>()
{
  return ::vapi_msg_id_http_static_enable_v2; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_http_static_enable_v2>>()
{
  return ::vapi_msg_id_http_static_enable_v2; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_http_static_enable_v2()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_http_static_enable_v2>(vapi_msg_id_http_static_enable_v2);
}

template <> inline vapi_msg_http_static_enable_v2* vapi_alloc<vapi_msg_http_static_enable_v2>(Connection &con)
{
  vapi_msg_http_static_enable_v2* result = vapi_alloc_http_static_enable_v2(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_http_static_enable_v2>;

template class Request<vapi_msg_http_static_enable_v2, vapi_msg_http_static_enable_v2_reply>;

using Http_static_enable_v2 = Request<vapi_msg_http_static_enable_v2, vapi_msg_http_static_enable_v2_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_http_static_enable_v2_reply>(vapi_msg_http_static_enable_v2_reply *msg)
{
  vapi_msg_http_static_enable_v2_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_http_static_enable_v2_reply>(vapi_msg_http_static_enable_v2_reply *msg)
{
  vapi_msg_http_static_enable_v2_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_http_static_enable_v2_reply>()
{
  return ::vapi_msg_id_http_static_enable_v2_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_http_static_enable_v2_reply>>()
{
  return ::vapi_msg_id_http_static_enable_v2_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_http_static_enable_v2_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_http_static_enable_v2_reply>(vapi_msg_id_http_static_enable_v2_reply);
}

template class Msg<vapi_msg_http_static_enable_v2_reply>;

using Http_static_enable_v2_reply = Msg<vapi_msg_http_static_enable_v2_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_http_static_enable_v3>(vapi_msg_http_static_enable_v3 *msg)
{
  vapi_msg_http_static_enable_v3_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_http_static_enable_v3>(vapi_msg_http_static_enable_v3 *msg)
{
  vapi_msg_http_static_enable_v3_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_http_static_enable_v3>()
{
  return ::vapi_msg_id_http_static_enable_v3; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_http_static_enable_v3>>()
{
  return ::vapi_msg_id_http_static_enable_v3; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_http_static_enable_v3()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_http_static_enable_v3>(vapi_msg_id_http_static_enable_v3);
}

template <> inline vapi_msg_http_static_enable_v3* vapi_alloc<vapi_msg_http_static_enable_v3>(Connection &con)
{
  vapi_msg_http_static_enable_v3* result = vapi_alloc_http_static_enable_v3(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_http_static_enable_v3>;

template class Request<vapi_msg_http_static_enable_v3, vapi_msg_http_static_enable_v3_reply>;

using Http_static_enable_v3 = Request<vapi_msg_http_static_enable_v3, vapi_msg_http_static_enable_v3_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_http_static_enable_v3_reply>(vapi_msg_http_static_enable_v3_reply *msg)
{
  vapi_msg_http_static_enable_v3_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_http_static_enable_v3_reply>(vapi_msg_http_static_enable_v3_reply *msg)
{
  vapi_msg_http_static_enable_v3_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_http_static_enable_v3_reply>()
{
  return ::vapi_msg_id_http_static_enable_v3_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_http_static_enable_v3_reply>>()
{
  return ::vapi_msg_id_http_static_enable_v3_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_http_static_enable_v3_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_http_static_enable_v3_reply>(vapi_msg_id_http_static_enable_v3_reply);
}

template class Msg<vapi_msg_http_static_enable_v3_reply>;

using Http_static_enable_v3_reply = Msg<vapi_msg_http_static_enable_v3_reply>;
}
#endif
