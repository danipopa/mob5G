#ifndef __included_hpp_policer_types_api_json
#define __included_hpp_policer_types_api_json

#include <vapi/vapi.hpp>
#include <vapi/policer_types.api.vapi.h>

namespace vapi {

}
#endif
